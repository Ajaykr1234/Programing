package com;

public class breakDemo {
	public static void main(String[] args) {
System.out.println("Q1. find the output of the given below program... ?");
		
              for(int i=1; i<=10; i++) {
			  System.out.println("ans :- "+ i  );
		  }
              
		
System.err.println("=============================================================");
System.out.println("Q2. find the output of the given below program... ?");
		
		  for(int j=1; j<=10; j++) {
			  System.out.println("ans:- "+j);
			  break;
		  }
		  
			
System.err.println("=============================================================");
System.out.println("Q3. find the output of the given below program... ?");
			
			  for(int k=1; k<=10; k++) {
				  System.out.println("Error:-  unreachable code!!! due to :break keyword will terminate the whole loop and come out from loop, hence it never reach to the next line   ");
				 break;
                //System.out.println("ans:- "+k); 
				 
			  }
			  
			  
System.err.println("================================================================");
System.out.println("Q4. find the output of the given below program... ?");
				
				  for(int l=1; l<=10; l++) {
					 
					 if(l==3 && l==7) {
						 break; 
					 }
					  System.out.println("ans:- "+l); 
				  }
				  System.out.println("Concept:- Here if condition never execute \nbecacuse L value never contain two value at a time And operator cheak both condition");
				  
				  
System.err.println("=====================================================================");
System.out.println("Q5. find the output of the given below program... ?");
				  				
				  				  for(int l=1; l<=10; l++) {
				  					 
				  					 if(l==3 || l==7) {
				  						 break; 
				  					 }
				  					  System.out.println("ans:- "+l); 
				  				  }
				
		  
		
	}

}
