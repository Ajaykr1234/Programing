package splitString;

public class String2_Integer {
	
	static int converter(String s) {
		int n=0,j=1;
		
		for(int i=s.length()-1; i>=0; i--) {
			n=n+j*(s.charAt(i)-48);
			
			j*=10;
		}
		return n;
		
	}
	public static void main(String[] args) {
		
		//Q3. Write a program to convert String into number/ integer format like s="123" n=123
		String s ="123";
		
		
		System.out.println(converter(s));
		
		int res =0;
		for(int i=0; i<s.length();i++) {
			int n = (s.charAt(i)-48);
			res=(res*10)+n;
		}
	
		System.out.println(res);
		
		
		//build in function
		int m=Integer.parseInt(s);
		System.out.println(m);

}
}