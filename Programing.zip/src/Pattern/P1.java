package Pattern;

import java.util.Scanner;

public class P1 {
	static void pattern(int n) {
		for(int i=1; i<=n; i++) {
			for(int j=1; j<=n; j++ ) {
				System.out.println(i +" "+j);
			}
		}
	}
public static void main(String[] args) {
	/*Enter yr number 3
	1 1
	1 2
	1 3
	2 1
	2 2
	2 3
	3 1
	3 2
	3 3*/
	
	Scanner sc = new Scanner( System.in);
	System.out.print("Enter yr number ");
	int n = sc.nextInt();
	
	pattern(n);
	
}
}
