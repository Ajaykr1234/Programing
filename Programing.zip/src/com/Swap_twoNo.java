package com;

public class Swap_twoNo {
 public static void main(String[] args) {
	 
// 01.write a program to swap the 2 number using temp variable
	int a=10;
	int b= 20;
	int temp =0;
	
	temp =a;
	a=b;
	b=temp;
	System.out.println(a+" "+b);
}

}
