package String;

public class S1 {
	public static void main(String[] args) {
		/*Declaration of string there are two ways which is given below 
		 
	    		01. String varname = "value";
        		02. String varname = new String("value");*/	
		String s1= "String1 ";
		String s2= new String("String2");
		System.out.println(s1);
		System.out.println(s2);
	}

}
