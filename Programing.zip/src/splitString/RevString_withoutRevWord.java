package splitString;

public class RevString_withoutRevWord {

	public static void main(String[] args) {
		
		//Q. Reverse String without reversing the word for ex:- book holy is  Ramayana o/p Ramayana is holy book.
		
		String s = "book holy is Ramayana";
		String[] arr=s.split(" ");
		String s1="";
		
		for(int i=arr.length-1; i>=0; i--) {
			
			s1 +=arr[i]+" ";
		}
		System.out.println(s1);
	}
}
