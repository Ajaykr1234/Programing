package String;

public class S13_WordPrint {
public static void main(String[] args) {
	//Q write a program to print word in given string
	
	String s= "all the best";
	String temp="";
	for(int i=0; i<s.length(); i++) {
		if(s.charAt(i)==' ') {
			System.out.println(temp);
			temp="";
		}else {
			temp+=s.charAt(i);
		}
	}
	System.out.println(temp);
}
}
