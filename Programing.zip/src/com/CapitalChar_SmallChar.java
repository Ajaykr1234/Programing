package com;

public class CapitalChar_SmallChar {
	public static void main(String[] args) {
		char c1 = 'A';
		//we  can not store the value with the add of (char+num) in other var 
              //	   c1 = c1+32;
		c1 +=32;
		System.out.println(c1);
		
		
		char c2 = 'a';
		c2-=32;
		System.out.println(c2);
		
		
		
		
		
		// Q1. why we need required 2byte for char?
       //		Ans:- char is mostly supported the unicode in unicode we can declare more than one 1 char like
		
		char c = '\u0950';
		System.out.println(c);
		
	}

}
