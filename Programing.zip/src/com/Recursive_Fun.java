package com;

import java.util.Scanner;

public class Recursive_Fun {
	 static int  i=0;
	static void display() {  //StackOverflowError
		System.out.println("hello");
		display();
	}
	
	static void display1(int n) {
		
		if(i<n) {
			System.out.println("hello");
			i++;
			display1(n);
		}
		
		 
		
		
		
	}
	
	
	
	
	
	public static void main(String[] args) {
		
//		display();
		Scanner sc = new Scanner(System.in);
		System.out.print("enter yr no : ");
		int n = sc.nextInt();
	display1(n);
		
		
	}

}
