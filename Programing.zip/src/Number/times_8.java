package Number;

import java.util.Scanner;

public class times_8 {
	static String ID(int n) {
		int rem =0;
		int count =0;
		while(n!=0) {
			rem=n%10;
			if(rem==8) {
				count++;
			}
			n=n/10;
		}
		return count>3?"Lucky Employee":"Unlucky Employee";
	}
	public static void main(String[] args) {
		System.out.println("Q1 Write a java program to print lucky employee or unlucy employee if employee id have more than 3times 8 then employee is lucky else not a lucky");
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter Employee no :");
			int id = sc.nextInt();
			System.out.println("ID "+id+" is "+ID(id));
	}

}
