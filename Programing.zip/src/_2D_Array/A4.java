package _2D_Array;

public class A4 {
	public static void main(String[] args) {
		int[][] arr = {{1,5,8,3},{7,6,2,9},{5,5,6,5}};
		
		//Advance for loop
		for (int[] ele : arr) {
			for (int ele1 : ele) {
				System.out.print(ele1+" ");
				
			}
			System.out.println();
		}
	}

}
