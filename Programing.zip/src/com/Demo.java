package com;

public class Demo {

	public static void main(String[] args) {
	
//	this is convert into respective value in ASSII table
		
		int a = 'A';
		System.out.println(a);
		
		
//this will be converted into respective dec value in ASSCII table
		char b = 65;
		System.out.println(b);
		
		
//binary number declaration with 0b
		int n= 0b11;
		System.out.println(n);
		
//octa decimal declaraton start with ZERO(0)
		int x=0;
		int y=01;
		int u=010;
		int w= 0100;
		int v=0101;
		System.out.println(x +" "+ y +" " +u+" "+w+ " "+v);
		
		
//hexa decimal declaration start with 0x
		int p = 0x10;
		int k = 0x11;
		
		int r =0x20;
		int l =0x21;
		
		System.out.println(p+" "+k+" "+r+" "+l);
	}

}
