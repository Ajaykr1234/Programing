package SIQ;

import java.util.Scanner;

public class Prime1_N {
	static boolean nPrimeNumber(int n) {
		int count=0;
		for(int i=1; i<=n; i++) {
			if(n%i==0) {
			   count++;	
			}
			
		}
		return count==2;
		
		
	}
	
     public static void main(String[] args) {
    	 Scanner sc = new Scanner (System.in);
    	 System.out.print("Enter yr number ");
    	 int n = sc.nextInt();
    	 for(int i=1; i<=n; i++) {
    		 if(nPrimeNumber(i)) {
    			 if(n==i) {
    			 System.out.println(i);
    			 
    		 }
    	 }
    	 
		
	}
     }
}
