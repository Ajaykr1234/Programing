package Pattern;

import java.util.Scanner;

public class P27 {
	static void pattern(int n) {
		for(int i=1; i<=n; i++) {
			for(int j=1; j<=n; j++) {
				if(i+j>=n+1) {
					System.out.print("* ");
				}else {
					System.out.print(" ");
				}
			}
			System.out.println();
		}
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
	    System.out.print("Enter yr number : ");
	    int n = sc.nextInt();
	    pattern(n);
		
	}

}
