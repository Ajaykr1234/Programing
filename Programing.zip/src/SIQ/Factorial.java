package SIQ;

import java.util.Scanner;

public class Factorial {
	
	
	static void factorial(int n){
		 
		System.out.print(n+" factorial is : " );
		for(int i=n; i>=1; i--) {
			System.out.print(i+" ");	
			
		}
		
	}
	
public static void main(String[] args) {
		System.out.println("Write a program to find factorial of a given number..? ");
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter yr no : ");
		int n = sc.nextInt();
		factorial(n);
		
	}

}
