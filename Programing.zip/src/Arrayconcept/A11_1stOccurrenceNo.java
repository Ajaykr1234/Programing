package Arrayconcept;

public class A11_1stOccurrenceNo {
	
	static int find(int[] arr, int k) {
		int max=arr[0];
		for(int ele: arr) {
			if(max<ele) {
				max=ele;
			}
		}
		int[] temp=new int[max+1];
		for(int ele: arr) {
			temp[ele]++;
			if(temp[ele]==k) {
				return ele;
			}
		}
		return -1;
	}
	
	
	public static void main(String[] args) {
		
		//Q write a program to find 1st occurrence element the given array 
		//like 7 2times and 4 2times but 4 occurrence 1st so o/p=4
		int[] arr = {1,7,4,2,4,7,8};
		int k=3;
		
		System.out.println(find(arr,k));
		
	}
	


}
