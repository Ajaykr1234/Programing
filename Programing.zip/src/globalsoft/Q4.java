package globalsoft;
import java.util.HashMap;
import java.util.Scanner;
public class Q4 {
	
	public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        System.out.println("enter yr t ");
	        int t = scanner.nextInt();
	        scanner.nextLine(); 

	        while (t-- > 0) {
	            int n = scanner.nextInt();
	            scanner.nextLine(); 

	            String[] yodaWords = scanner.nextLine().split(" ");
	            String[] normalWords = scanner.nextLine().split(" ");

	            int yodanessLevel = calculateYodanessLevel(yodaWords, normalWords);
	            System.out.println(yodanessLevel);
	        }

	        scanner.close();
	    }

	    static int calculateYodanessLevel(String[] yodaWords, String[] normalWords) {
	        int n = yodaWords.length;
	        HashMap<String, Integer> wordToIndex = new HashMap<>();

	        for (int i = 0; i < n; i++) {
	            wordToIndex.put(normalWords[i], i);
	        }

	        int inversions = 0;

	        for (int i = 0; i < n; i++) {
	            for (int j = i + 1; j < n; j++) {
	                if (wordToIndex.get(yodaWords[i]) > wordToIndex.get(yodaWords[j])) {
	                    inversions++;
	                }
	            }
	        }

	        return inversions;
	    }
	}



