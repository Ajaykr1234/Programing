package SIQ;

import java.util.Scanner;

public class PrimeNo_not {
	static String isPrime(int n) {
		if(n<=1) {
			return "Not a Prime";
		}
		for(int i=2; i<=n/2; i++) {
			if(n%i==0) {
				return "Not a Prime";
			}
			
		}
		return "Prime";
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter yr no = ");
		int n = sc.nextInt();
		System.out.print(n+" is a");
		System.out.println(isPrime(n));
		
	}
}
