package Number;

import java.util.Scanner;

public class SunnyNo_not {
	static boolean isPrime(int n ) {
		
		for(int i=1; i<=n; i++) {
			if(n==(i*i)) {
			 return true;	
			}
		}
		return false;
	}
	
   public static void main(String[] args) {
		System.out.println("Q1.write a java program to find given no is sunny number or not \n for example (n+1)=perfect Sq, 8+1=9 ..? ");
		Scanner sc = new Scanner(System.in);
		System.out.print("enter yr no : ");
		int n = sc.nextInt();
		if(isPrime(n+1)) {
			System.out.println(n+" it is a sunny no :"+(n+1));
		}else {
			System.out.println(n+ " not a sunny no : "+(n+1));
		}
		
}
}
