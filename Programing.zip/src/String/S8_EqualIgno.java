package String;

public class S8_EqualIgno {
	int x =10;
	int y=40;
	
//	public static S8_EqualIgno(int x, int y) {
//		
//		this.x = x;
//		this.y = y;
//	}

//	publicS8_EqualIgno(int x, int y) {
//		
//		this.x = x;
//		this.y = y;
//	}

}
