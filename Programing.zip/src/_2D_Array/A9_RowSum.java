package _2D_Array;

public class A9_RowSum {
	public static void main(String[] args) {
		
//		Q write a java program to find which row contain max sum
		int[][] arr = {{1,2,3},{4,5,6},{7,8,9}};
		int maxsum=0,k=0;
		for (int i = 0; i < arr.length; i++) {
			int sum=0;
			for (int j = 0; j < arr[i].length; j++) {
				sum+=arr[i][j];
			
			}
			if(maxsum<sum) {
				maxsum=sum;
				k=i+1;
			}

		}
	 System.out.println(k);
}
}
