package com;




	
public class Test {
	static int x=10;
	
	public static void main(String[] args) {
		  
	
   
//	 test2 t2= new test2();
	 System.out.println(x);
	
	
	}
	
}	







