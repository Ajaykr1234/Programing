package com;

public class AssingmentOp {
	public static void main(String[] args) {
		
		   int a=10;
		   a+=2;       //it mean  a = a+2 
		   System.out.println(a);
		   
		   int b=10;
		   b*=2;       //it mean  a = a*2 
		   System.out.println(b);
		   
		   double c=10;
		   c/=2;       //it mean  c= c/2 
		   System.out.println(c);
		   
		   double d=10;
		   d%=2;       //it mean  d= d/2 
		   System.out.println(d);
		  
System.out.println("-----------------------------------------------");
		   
System.out.println("-----------------------------------------------");

System.out.println("-----------------------------------------------");
             
           char e = 'A';
               e+=1;               // it mean e = e+1 that mean e = 'A'+1 ,A gives ASCII value 65 and plus 1 total is 66
               
//             e = e+1             //here we cannot add directly char+1  we getting compile time error
            System.out.println(e);  // but logic is 66 again store in character value so result is converted into char value mean result is = B
            
		   
		   
		   
	}

}
