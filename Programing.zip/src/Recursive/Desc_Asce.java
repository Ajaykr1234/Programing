package Recursive;

import java.util.Scanner;

public class Desc_Asce {
	
	static void pattern(int n) {
		if(1<=n) {
			System.out.print(n);
			pattern(n-1);
			System.out.print(n);
		}
	}
	
	public static void main(String[] args) {
System.out.println("Q1 Write a program to find (i/p = 5  o/p=5432112345 ..?");
		
		Scanner sc = new Scanner (System.in);
		System.out.print("Enter yr no : ");
		int n = sc.nextInt();
	    pattern(n);
		
	}

}
