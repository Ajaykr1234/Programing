package String;

public class S5 {
	public static void main(String[] args) {
		// using for loop to find index number of the given String 
		String s1="Ramayana is a holy book";
		for(int i=0; i<s1.length(); i++) {
			System.out.print(s1.charAt(i)+" ");
		}
	}

}
