package Pattern;

public class P18 {

}
