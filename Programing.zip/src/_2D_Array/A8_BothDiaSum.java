package _2D_Array;

public class A8_BothDiaSum {
	
	public static void main(String[] args) {
		
//		Q write a program to find diagonal which sum is Greater than other diagonal
		int[][] arr = {{1,2,3},{4,5,6},{7,8,9}};
		int sum=0,sum1=0;
		for (int i = 0; i < arr.length; i++) {
			
			for (int j = 0; j < arr[i].length; j++) {
				if(i==j) {
					sum+=arr[i][j];
				}
				if(i+j==arr.length-1) {
					sum1+=arr[i][j];
				}
				
			}
			
		}
		if(sum>sum1) {
			System.out.println("1st dia is Greater than 2nd ");
		}else {
			System.out.println("2nd dia is Greater than 1st ");
		}
		
	}

}
