package _2D_Array;

import java.util.Scanner;

public class A6_userInput {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter yr row size : ");
		int row = sc.nextInt();
		System.out.print("Enter yr col size : ");
		
	
		int col = sc.nextInt();
		int[][] arr= new int[row][col];
		
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				System.out.print("Enter yr "+i+","+j+" value ");
				arr[i][j] = sc.nextInt();
				
			}
			
		}
		System.out.println("Matrix got created....");
		for(int[] ele:arr) {
			for(int ele1:ele) {
				
				System.out.print(ele1+" ");
			}
			System.out.println();
		}
		
	}

}
