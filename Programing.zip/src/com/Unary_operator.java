package com;

public class Unary_operator {
	public static void main(String[] args) {
		
		
System.out.println("type of operator:- 01.increment:-  (a).post increment (b).pre-increment \n\t\t   02.decrement:-  (a).post-decrement (b).pre-decrement");
System.out.println("===========================================================================================");
  
		System.out.println("post increment .............");
		int a = 10;
		System.out.println(a++);
		
		
		 System.out.println("pre increment .............");
		int b = 10;
		System.out.println(++b);
		
System.out.println("===========================================================================================");
System.out.println("post decrement  .............");
		int c = 10;
		System.out.println(c--);
		 System.out.println("pre decrement .............");
		 int d= 10;
		System.out.println(--d);
		
System.out.println("===========================================================================================");
System.out.println("Q1. find the output of the given below program............");
		int x = 0;
		x=x++;
		x=x++;
		x=x++;
		x=x++;
		System.out.println("ans :- "+x);
		
System.out.println("===========================================================================================");
System.out.println("Q2. find the output of the given below program............");
		int y = 0;
		y=++y;
		y=++y;
		y=++y;
		y=++y;
		System.out.println("ans :- "+y);
		
System.err.println("===========================================================================================");
System.out.println("Q3. find the output of the given below program............");
		int x1 = 0;
		x1=x1--;
		x1=x1--;
		x1=x1--;
		x1=x1--;
		System.out.println("ans :- "+x1);
		
System.out.println("===========================================================================================");
System.out.println("Q4. find the output of the given below program............");
		int y1 = 0;
		y1= --y1;
		y1= --y1;
		y1= --y1;
		y1= --y1;
		System.out.println("ans :- "+y1);
		
System.out.println("===========================================================================================");
System.out.println("Q5. find the output of the given below program............");
		int x2 = 100;
		    x2++;
		System.out.println("ans1 :- "+x2);
		    ++x2;
		System.out.println("ans2 :- "+x2); 
		   x2--;
		System.out.println("ans3 :- "+x2);
		  --x2;
		 System.out.println("ans4 :- "+x2);
		 
System.out.println("===========================================================================================");
System.out.println("Q6. find the output of the given below program............");
			int m = 0;
			int n = 0;
			n =m++;
			System.out.println("ans1 :- "+m);
			System.out.println("ans2 :- "+n);
		    System.out.println("........................................................");
			int p = 0;
			int q = 0;
			q = ++p;
			System.out.println("ans3 :- "+p);
			System.out.println("ans4 :- "+q);
            System.out.println("........................................................");
			int r = 0;
			int s = 0;
			s = r--;
			System.out.println("ans5 :- "+r);
			System.out.println("ans6 :- "+s);
            System.out.println("........................................................");
			int f = 0;
			int g = 0;
			g = --f;
			System.out.println("ans7 :- "+f);
			System.out.println("ans8 :- "+g);
			
System.out.println("===========================================================================================");
System.out.println("Q7. find the output of thegiven below program............");
				int u = 0;
				int v = 0;
				v = u++ + ++u;
				System.out.println("ans1 :- "+v);//2
				System.out.println("ans1 :- "+u);//2
                System.out.println("........................................................");
                int u1 = 0;
				int v1 = 0;
				v1 = u1-- + --u1;
				System.out.println("ans1 :- "+v1);//-2
				System.out.println("ans1 :- "+u1);//-2
		
	
System.out.println("===========================================================================================");
System.out.println("Q8. find the output of thegiven below program............");
       int e =1,h=2,k=3;
       System.out.println(k++ +" "+e++);
       if(false);{
    	   System.out.println(k++ +" "+h++ +" "+k++ +" "+ e++);
       }
       
	System.out.println(e+h+k);
	}
	

}
