package splitString;

public class Split_method {

	
	public static void main(String[] args) {
		//Q write a program split the given string in the given string 
		String s = "hi hello bye";
		int c =0;
		for(int i=0; i<s.length(); i++) {
			if(s.charAt(i)==' ') {
				c++;
			}
		}
		String[] arr=new String[c+1];
		int k=0;
		String temp="";
		for(int i=0; i<s.length(); i++) {
			if(s.charAt(i)==' ') {
				arr[k]=temp;
				k++;
				temp="";
			}else {
				temp+=s.charAt(i);
			}
		}
		arr[k]=temp;
		
		for(String ele:arr) {
			System.out.println(ele);
		}
	}
}
