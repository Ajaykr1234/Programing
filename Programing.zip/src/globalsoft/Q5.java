package globalsoft;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class Q5 {
	
	
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        System.out.println("enter yr t values");
	        int t = scanner.nextInt(); 
	        scanner.nextLine(); 

	        while (t-- > 0) {
	            int n = scanner.nextInt(); 
	            scanner.nextLine(); 

	            List<String> mergedCommands = new ArrayList<>();
	            int totalDelete = 0;
	            StringBuilder mergedCommand = new StringBuilder();

	            for (int i = 0; i < n; i++) {
	                int m = scanner.nextInt(); 
	                int delete = 0;
	                int insert = 0;

	                for (int j = 0; j < m; j++) {
	                    String operation = scanner.next();
	                    int k = scanner.nextInt();

	                    if (operation.equals("R")) {
	                        delete += k;
	                    } else if (operation.equals("D")) {
	                        delete -= k;
	                    } else if (operation.equals("C")) {
	                        insert += k;
	                        mergedCommand.append("C ").append(insert).append(" ").append(scanner.next()).append("\n");
	                    }
	                }

	                totalDelete += delete;
	            }

	            if (totalDelete > 0) {
	                mergedCommand.insert(0, "D " + totalDelete + "\n");
	            }

	            mergedCommands.add(mergedCommand.toString());
	            
	            
	            System.out.println(mergedCommands.size());
	            for (String cmd : mergedCommands) {
	                System.out.print(cmd);
	            }
	        }

	        scanner.close();
	    }
	}


