package SIQ;

public class A1_test {
	public static void main(String[] args) {
        int n =11;
        int c=0;
        int count=0;
  	  for(int i=1; i<=n; i++) {
  		  if(n%i==0) {
  			  count++;
  		  }
  	  
        }
        System.out.println(c==2?"prefect":"not a perfect");
    }
}
