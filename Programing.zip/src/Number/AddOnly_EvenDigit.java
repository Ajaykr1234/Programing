package Number;

import java.util.Scanner;

public class AddOnly_EvenDigit {
	static int sumeven(int n) {
		int rem = 0;
		int sum = 0;
		while(n!=0) {
			rem=n%10;
			if(rem%2==0) { 
				sum+=rem;
			}
			n=n/10;
		}
		return sum;
	}
	
	
	
	static int sumodd(int n) {
		int rem1 = 0;
		int sum1 = 0;
		while(n!=0) {
			rem1=n%10;
			if(rem1%2==1) {  
				sum1+=rem1;
			}
			n=n/10;
		}
		return sum1;
	}
	
	public static void main(String[] args) {
		System.out.println("Q1.write a java program to find sum of only even digit to given number  ..? ");
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter yr no : ");
		int n =sc.nextInt();
		System.out.println(n+" the sum of their even digit is "+sumeven(n));
		
		System.out.println("==========================================================");
		System.out.println("Q2.write a java program to find sum of only odd digit to given number  ..? ");
		System.out.println(n+" the sum of their odd digit is "+sumodd(n));
	}

}
