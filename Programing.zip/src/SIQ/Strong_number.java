package SIQ;

import java.util.Scanner;

public class Strong_number {
	static int digitFact(int n) {
	  int fact =1;
	  for(int i=1; i<=n; i++) {
		  fact *=i;
	  }
		return fact;
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter yr number : ");
		int n = sc.nextInt();
		int m=n;
		int rem=0,sum=0;
		while(n!=0) {
			rem = n%10;
			sum += digitFact(rem);
			n=n/10;
		}
		if(m==sum) {
			System.out.println("Strong number ");
		}else {
			System.out.println("Not a strong number ");
		}
		
	}

}
