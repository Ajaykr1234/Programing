package arrayString;

public class String2_CharArray {
	
	static void sting_charArray(String s) {
		 char[] arr = new char[s.length()];
		 
		 for(int i=0; i<arr.length; i++) {
			 arr[i]=s.charAt(i);
		 }
		 for(char ele : arr) {
			 System.out.println(ele);
		 }
	}
	
	
	
	public static void main(String[] args) {
		
	 String s = "apple";
	 
	 sting_charArray( s);
	 
	 
	 System.out.println("==============================");
	 // predefine function
	 char[] arr1 = s.toCharArray();
	
	 for(char ele : arr1) {
		 System.out.println(ele);
	 }
	System.out.println("======================================");
		
	}

}
