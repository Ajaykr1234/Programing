package com;
import java.util.Scanner;
public class Nth_PrimeNo {
  static boolean prime(int p) {
	  if(p<=1) {
		  return false;
	  }
	  for(int i=2; i<=p/2; i++) {
		  if(p%i==0) {
			  return false;
		  }
	  }
	  return true;
  }
  public static void main(String[] args) { 
	  System.out.println("Q1. Write a java Program to find Nth prime no..?");
	Scanner Sc = new Scanner(System.in);
	System.out.print("Enter yr no : - ");
	int n = Sc.nextInt();
	int count = 0;
	for(int i=2; ; i++) {
		if(prime(i)) {
			count++;
			
		}
		if(count== n) {
			System.out.println(i);
			break;
		}
	}
	
}
}
