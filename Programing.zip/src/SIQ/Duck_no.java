package SIQ;

import java.util.Scanner;

public class Duck_no {
	static String  cheak(int n) {
		int rem=0;
		while(n!=0) {
			rem=n%10;
			if(rem==0) {
				 return "Duck no";
			}
			n=n/10;
			
		}
		return "not a duck no";
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter yr number : ");
		int n = sc.nextInt();
		System.out.println(cheak(n));
		
	}

}
