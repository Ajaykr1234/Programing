package SIQ;
import java.util.Scanner;
public class Prime_NotPrime {
	
	
	static String isPrime(int n) {
	  int count=0;
	  for(int i=1; i<=n; i++) {
		  if(n%i==0) {
			  count++;
		  }
	  }
	  return count==2?"prime":"not prime";
	}

	
public static void main(String[] args) {
	System.out.println("Write a program to find given no is prime no or not..? ");
	Scanner sc = new Scanner(System.in);
	System.out.print("Enter yr no : ");
	int n = sc.nextInt();
	System.out.println(isPrime(n));
	
}
}
