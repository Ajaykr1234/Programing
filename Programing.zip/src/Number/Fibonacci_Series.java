package Number;
import java.util.Scanner;
public class Fibonacci_Series {
	
	static void nthFib(int n) {
		int n1=0,n2=1,sum=0,i=1;
		while(i<=n) {
			System.out.println(n1);
			sum=n1+n2;
			n1=n2;
			n2=sum;
			i++;
		}
	}	
	static void nthWith_Forloop(int n) {
		int sum=0;
		for(int i=0,j=1,k=0; k<=n; k++ ){
			System.out.println(i);
			sum=i+j;
			i=j;
			j=sum;


		}
	}
	
	
	static void tillFib(int n) {
		
		int n1=0,n2=1,sum=0;
		while(n1<=n) {
			System.out.println(n1);
			sum=n1+n2;
			n1=n2;
			n2=sum;
		}
		
	}
	
	static void  rangeFib(int n) {
		int n1=0,n2=1,sum=0,range=1000;
		
		while(n1<=range) {
			if(n1>=n) {
				System.out.println(n1);
			}
		 sum=n1+n2;
		 n1=n2;
		 n2=sum;
		}
		
	}
	static boolean numberisFib(int n) {
	int n1=0,n2=1,sum=0;
		
		while(n1<=n) {
			if(n1==n) {
			 return true;
			}
		 sum=n1+n2;
		 n1=n2;
		 n2=sum;
		}
		return false;
		
	}
	
		

	
	public static void main(String[] args) {
		
	  System.out.println("Q1. Write a java program to find Fibonacci series ..?");
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter yr number : ");
		int n = sc.nextInt();
//        nthFib(n);
//		nthWith_Forloop(n);
//		 
//		 System.out.println("Q2.Write a java program to find Fibonacci series till 1000");
//      	 tillFib(n);
//		 
//		 System.out.println("Q2.Write a java program to find Fibonacci series till 400 to 1000");
//		 rangeFib(n);
//		System.out.println("Q2.Write a java program to find no is  Fibonacci or not ");
//		
		System.out.println(numberisFib(n)?"Fib ": "not fib");
//		
		
		
	}

}
