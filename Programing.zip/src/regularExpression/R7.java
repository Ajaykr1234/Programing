package regularExpression;
import java.util.regex.*;
public class R7 {
 public static void main(String[] args) {
	//WARE to check whether the String Start with alphabets  or num
	 String s = "123Ajay123"; 
	 Pattern p = Pattern.compile("[a-z,A-Z,0-9].*");
	 Matcher m = p.matcher(s);
	 boolean b = m.matches();
	 System.out.println(b);
}
}
