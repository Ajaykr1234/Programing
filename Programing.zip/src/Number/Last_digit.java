package Number;
import java.util.Scanner;
public class Last_digit {
	
	static int Last_d(int n) {
	  int rem=n%10;
		return rem;
	}
	
	
	
	public static void main(String[] args) {
		System.out.println("01.Write a program to find last Digit of a number..?");
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter yr number : ");
		int n= sc.nextInt();
		
		System.out.println(n+" last digit is : "+Last_d(n));
		
	}
}
