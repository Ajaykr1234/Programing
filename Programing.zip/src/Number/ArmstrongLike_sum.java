package Number;

import java.util.Scanner;

public class ArmstrongLike_sum {
	static int powerofdigit(int n,int exp) {
		int power =1,rem=0;
		for(int i=1;i<=exp; i++) {
			power *=n;
		}
		return power;
	}
	
	public static void main(String[] args) {
		System.out.println("Q1 Wite a java program find sum of digit by power count of each digit ");
		System.out.println("explain:-n=123 exp=2 mean (1^2+2^2+3^2)sum=14");
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter yr number : ");
		int n = sc.nextInt(),m=n;
		System.out.print("Enter yr exp : ");
		int exp = sc.nextInt();
		int rem=0,sum=0;
		while(n!=0) {
			rem=n%10;
			sum += powerofdigit(rem,exp);
			n=n/10;
		}
		
		System.out.print(m+" the sum of it's digit power is "+sum);
	}

}
