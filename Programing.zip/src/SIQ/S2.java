package SIQ;

public class S2 {
	static boolean odd(int n){
		if (n%2==1){
			return true;
		}
		return false;
	}
	public static void main(String[] args) {
		
		//cheak the given  array is Prime array is not if the array said to be prime Array if Array should contain prime element on prime index number
		int[] arr = {6,7,13,7,16,3};
		boolean b=false;
		for(int i=1; i<arr.length; i++){
			if(i%2==1){
				b=odd(arr[i]);
				
			}
		}
			if(b==true){
				System.out.println("Prime Array");
			}else{
				System.out.println("not a prime Array");
			}
		
	}

}
