package String;

import java.util.Scanner;

public class S7_countVowelCon {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Write a java program to find how many vowel and consonant  present in the user given  String");
		System.out.print("Enter yr String : ");
		String s1 = sc.nextLine();
		s1=s1.toLowerCase();
		int V=0,C=0;
		for(int i=0; i<s1.length(); i++) {
			char c = s1.charAt(i);
			if(c=='a'|| c=='e' || c=='i' || c=='o' || c=='u') {
				V++;
			}else if(c==' ') {
				continue;
			}
			else {
				C++;
			}
		}
		System.out.println("Vowel present in "+s1+" given String is "+V);
		System.out.println("consonant present in "+s1+" given String is "+C);
	}

}
