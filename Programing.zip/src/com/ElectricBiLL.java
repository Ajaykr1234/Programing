package com;
import java.util.Scanner;

public class ElectricBiLL {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter customer Id = ");
        int id = sc.nextInt();
        System.out.print("Enter customer Name = ");
        String name = sc.next();
        System.out.print("Enter unit = ");
        double units = sc.nextDouble();
        if (units <= 199) {
        	 if (units <= 83.3) {
                 double Bill = (units * 1.2);
                 System.out.println("Amount charge @ Rs 1.2 per unit " + units + " = " + Bill);
                 double surcharge = 0.0;
                 System.out.println("service Charge = " + surcharge);
                 System.out.println("Net Amount Paid by is customer is = " + (Bill + surcharge));
                 System.out.println(
                         " the minimium bill should be @ Rs 100! then your are Eligible to pay Your Bill");
             } else {
                 double Bill = (units * 1.2);
                 System.out.println("Amount charge @ Rs 1.2 per unit " + units + " = " + Bill);
                 double surcharge = 0.0;
                 System.out.println("service Charge = " + surcharge);
                 System.out.println("Net Amount Paid by is customer is = " + (Bill + surcharge));
             }

        } else if (units >= 200 && units <= 399) {
            if (units <= 266.6) {
                double Bill = (units * 1.5);
                System.out.println("Amount charge @ Rs 1.5 per unit " + units + " = " + Bill);
                double surcharge = 0.0;
                System.out.println("service Charge = " + surcharge);
                System.out.println("Net Amount Paid by is customer is = " + (Bill + surcharge));
            } else {
                double Bill = (units * 1.5);
                System.out.println("Amount charge @ Rs 1.5 per unit " + units + " = " + Bill);
                double surcharge = ((units * 1.5) * 15) / 100;
                System.out.println("Survice Charge = " + surcharge);
                System.out.println("Net Amount Paid by is customer is = " + (Bill + surcharge));
            }

        } else if (units >= 400 && units <= 599) {
            double Bill = (units * 1.8);
            System.out.println("Amount charge @ Rs 1.8 per unit " + units + " = " + Bill);
            double surcharge = ((units * 1.8) * 15) / 100;
            System.out.println("Survice Charge = " + surcharge);
            System.out.println("Net Amount Paid by is customer is = " + (Bill + surcharge));

        } else if (units >= 600) {
            double Bill = (units * 2.00);
            System.out.println("Amount charge @ Rs 2.00 per unit " + units + " = " + Bill);
            double surcharge = ((units * 2.00) * 15) / 100;
            System.out.println("Survice Charge = " + surcharge);
            System.out.println("Net Amount Paid by  customer is = " + (Bill + surcharge));

        } else {
            System.out.println("Invalid data");
        }
    }


}
