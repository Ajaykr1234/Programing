package Recursive;

import java.util.Scanner;

public class Fibonacci_Series {
static	int n1=0,n2=1,sum=0;
static void fib(int n) {
	
	if(1<=n) {
		System.out.println(n1);
		sum=n1+n2;
		n1=n2;
		n2=sum;
		
		fib(n-1);
	}
}


	
	public static void main(String[] args) {
System.out.println("Q1 Write a program to print fibnonacci series ..?");
		
		Scanner sc = new Scanner (System.in);
		System.out.print("Enter yr no : ");
		int n = sc.nextInt();
		fib(n);
		
	}

}
