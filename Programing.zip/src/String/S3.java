package String;

public class S3 {
	public static void main(String[] args) {
		
		//to using charAt(indexno) we can find any index char which is present in String other wise exception out of bound
		String s1 = "String";
		System.out.println(s1.charAt(0));
		System.out.println(s1.charAt(1));
		System.out.println(s1.charAt(2));
		System.out.println(s1.charAt(3));
		System.out.println(s1.charAt(4));
		System.out.println(s1.charAt(5));
		System.out.println("========================================");
		// to find the length of any String  we can call predefine function called [length();]
		System.out.println(s1.length());
		System.out.println("=====================================");
		//using length() function we can print all element with the help of loop
		for(int i=0; i<s1.length(); i++) {
			System.out.println(s1.charAt(i));
		}
		
	}

}
