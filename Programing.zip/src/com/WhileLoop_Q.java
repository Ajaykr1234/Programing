package com;
import java.util.Scanner;
public class WhileLoop_Q {
	public static void main(String[] args) {
		System.out.println("Q1. Write a java program to find number n to 1 using while loop..?");
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter yr number : - ");
		int n= sc.nextInt();
		
		while(n>=1) {
			System.out.println(n);
			n--;
		}
		
		
		System.out.println("Q2. Write a java program to find sum of n   natural number ..?");
	
		System.out.print("Enter yr number : - ");
		int m= sc.nextInt();
		double sum = 0.0;
		while(m>=1) {
		
			sum +=m;
			m--;
			
		}
		System.out.println("the sum of natural number is "+sum);
	}

}
