package InheritPro;

public class A extends B{

	static void test() {
		System.out.println("i am test method if A class");
	}
	void disp() {
		System.out.println("runnig  display");
	}
}
