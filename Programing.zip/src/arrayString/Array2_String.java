package arrayString;

public class Array2_String {
	
	static String  arry_sting(char[] arr) {
		String s = "";
		for(int i=0; i<arr.length; i++) {
			s += arr[i];
		}
		return s;
	}
	
	
	
	public static void main(String[] args) {
		
		char[] arr = {'a','p','p','l','e'};
		System.out.println(arry_sting(arr));
		
		System.out.println("============================");
		//Another way
		String s = new String(arr);
		System.out.println(s);
		
		
	}

}
