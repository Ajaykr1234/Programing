package Pattern;

public class P16 {

}
