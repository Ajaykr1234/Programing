package _2D_Array;

import java.util.Scanner;

public class Addtwonumber { 

	static int add(int[][] matric){
		int sum=0;
		for (int i = 0; i < matric.length; i++) {
			for (int j = 0; j < matric[i].length; j++) {
				sum +=matric[i][j];
			}
		}

		return sum;
	}
	static int adddia(int[][] matric){
		int sum=0;
		for (int i = 0; i < matric.length; i++) {
			for (int j = 0; j < matric[i].length; j++) {
				if(i==j){
					sum+=matric[i][j];
				}
			}
		}
		return sum;
	}

	static int adddia1(int[][] matric){
		int sum=0;
		for (int i = 0; i < matric.length; i++) {
			for (int j = 0; j < matric[i].length; j++) {
				if(i+j==matric.length-1){
					sum+=matric[i][j];
				}
			}
		}
		return sum;
	}
	static int rowmaxsum(int[][] matric){
	
		int maxsum=0,n=0;
		for (int i = 0; i < matric.length; i++) {
			int sum = 0;
			for (int j = 0; j < matric[i].length; j++) {
				sum +=matric[i][j];
				
			}
			if(sum>maxsum) {
				maxsum = sum;
				n=n+1;
			}
		}
		return n;
	}
  public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter row");
	int row = sc.nextInt();
	System.out.println("Enter col ");
	int col = sc.nextInt();
	int[][] matric = new int[row][col];

	for(int i=0 ; i<matric.length; i++){
		for (int j=0;j<matric[i].length;j++){
			System.out.print("Enter element of array : ");
			matric[i][j] = sc.nextInt();
	}
	
}
for (int[] is : matric) {
		for (int is2 : is) {
			System.out.print(is2+" ");
		}
		System.out.println();
	}

	System.out.println(" sum of all element is "+add(matric));
	System.out.println("sum of only dia element "+adddia(matric));
	System.out.println("sum of 2nd dia element is "+adddia1(matric));
	System.out.println("row "+rowmaxsum(matric)+" contans max sum");
}
}