package com;

public class relation_opeartor {
  public static void main(String[] args) {
	  int n = 9;
	  System.out.println(n%2==0);
	  int a=10,b=20,c=30,d=40;
	  System.out.println(a+20>=c-10);
	  System.out.println((a*b)*2==(c-d)+30);
	
}

}
