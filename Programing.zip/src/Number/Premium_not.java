package Number;

import java.util.Scanner;

public class Premium_not {
	
	static boolean isPrime(int n) {
	
	  int c=0;
	  for(int i=1; i<=n ; i++) {
		  if(n%i==0) {
			  c++;
		  }
		  
	  }
	  return c==2;
		
		}
	
	
	
	
	public static void main(String[] args) {
		System.out.println("Q1.Write a program to find Premium number (if digit repeated for prime count in given number then it is premium no else not");
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter yr digit :");
			int d = sc.nextInt();
	    System.out.print("Enter yr no :");
			int n = sc.nextInt();
			int rem=0;
			int count=0;
			while(n!=0) {
				rem=n%10;
				if(rem==d) {
					count++;
			}
				n=n/10;
		 }
			if(isPrime(count)==true) {
				System.out.println("premium");
			}else {
				System.out.println("not a premium");
			}
			
	}

}
