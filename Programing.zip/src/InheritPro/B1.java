package InheritPro;

public abstract class B1 extends B  {
//	 void disp() {
//		 
//	 }
	abstract void disp(); 
}
