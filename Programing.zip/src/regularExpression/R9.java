package regularExpression;
import java.util.regex.*;
public class R9 {
 public static void main(String[] args) {
	//WARE to check whether the String contain starting alpha 3 and character number 4 next
	 String s = "Aja1234"; 
	 Pattern p = Pattern.compile("[a-z,A-Z,]{3}[0-9]{4}.*");
	 Matcher m = p.matcher(s);
	 boolean b = m.matches();
	 System.out.println(b);
}
}