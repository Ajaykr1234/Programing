package Pattern;

public class P17 {

}
