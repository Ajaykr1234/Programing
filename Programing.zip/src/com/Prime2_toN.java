package com;

import java.util.Scanner;

public class Prime2_toN {
	static boolean isPrime(int n) {
		if(n<=1) {
			return false;
		}
		for(int i=2; i<=n/2; i++) {
			if(n%i==0) {
				return false;
			}
		}
		return true;
	}
	public static void main(String[] args) {
		System.out.println("Q1. write a program to find n prime number..?");
		Scanner sc = new Scanner(System.in);
		System.out.print("enter yr no:- ");
		int m = sc.nextInt();
		for(int i=2; i<=m; i++) {
			if(isPrime(i)) {
				System.out.println(i);
			}
		}
	}

}
