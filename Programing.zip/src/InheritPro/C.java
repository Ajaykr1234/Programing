package InheritPro;

public interface C {
  abstract void walk();
}
