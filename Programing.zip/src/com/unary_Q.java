package com;

public class unary_Q {
	public static void main(String[] args) {
System.err.println("===========================================================================================");
System.out.println("Q1. find the output of the below given program............");
		int i=2147483647;
		  i++;          // we can do like (i=i++)
          System.out.println("ans :- "+i);
          System.out.println("the range of the integer value is -2^31 to 2^31-1");	
	   
System.err.println("===========================================================================================");
System.out.println("Q2. find the output of the below given program............");
		byte b=127;
		  b++;          // we can do like (b=b++)
		 System.out.println("ans :- "+b);
	     System.out.println("the range of the byte value is -128 to 127");	

System.err.println("===========================================================================================");
System.out.println("Q3. find the output of the below given program............");
		short s=32767;
		  s++;          // we can do like (i=i++)
		 System.out.println("ans :- "+s);
	    System.out.println("the range of the short value is -32768 to 32767");	
	   
System.err.println("===========================================================================================");
System.out.println("Q4. find the output of the below given program............");
		 double d =2.2;
		  d++;          // we can do like (d=d++)
		 System.out.println("ans :- "+d);
System.err.println("===========================================================================================");
System.out.println("Q5. find the output of the below given program............");
			 char c ='A';
			  d++;          // we can do like (d=d++)
			 System.out.println("ans :- "+c);

System.err.println("===========================================================================================");
System.out.println("Q6. find the output of the below given program............");
     int n =10;
      n--;
     System.out.println("ans1 : "+n);
     double dou=8.9;
     System.out.println("ans2 : "+dou);
     char cha='A';
      cha--;
     System.out.println("ans3 : "+cha);
     
			 
			 
			 
		   
	   
	}

}
