package regularExpression;
import java.util.regex.*;
public class R10 {
 public static void main(String[] args) {
	//WARE to check whether the String contain starting alpha 3 to 5 and character number 0 to 4 next n number of z
	 String s = "Aja1234zzzzzzz"; 
	 Pattern p = Pattern.compile("[a-z,A-Z,]{3,5}[0-9]{0,4}z*");
	 Matcher m = p.matcher(s);
	 boolean b = m.matches();
	 System.out.println(b);
}
}