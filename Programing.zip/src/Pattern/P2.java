package Pattern;

import java.util.Scanner;

public class P2 {
	
	static void pattern(int n) {
		for(int i=1; i<=n; i++) {
			for(int j=1; j<=n; j++) {
				System.out.print(i+""+j +" ");
				
			}
			System.out.println();
		}
	}
	
	
	public static void main(String[] args) {
			/* Enter yr number : 5
				11 12 13 14 15 
				21 22 23 24 25 
				31 32 33 34 35 
				41 42 43 44 45 
				51 52 53 54 55 */
		Scanner sc = new Scanner(System.in);
	     System.out.print("Enter yr number : ");
	     int n = sc.nextInt();
	     pattern(n);
	}

}
