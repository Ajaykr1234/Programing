package Pattern;

import java.util.Scanner;

public class P3 {
	static void pattern(int n) {
		for(int i=1; i<=n; i++) {
			for(int j=1; j<=n; j++) {
				System.out.print(i+ " ");
			}
			System.out.println();
		}
	}
	
public static void main(String[] args) {
	              /*
	                Enter yr number : 5

						1 1 1 1 1 
						2 2 2 2 2 
						3 3 3 3 3 
						4 4 4 4 4 
						5 5 5 5 5
	               					*/
	Scanner sc = new Scanner(System.in);
    System.out.print("Enter yr number : ");
    int n = sc.nextInt();
    pattern(n);
	
}
}
