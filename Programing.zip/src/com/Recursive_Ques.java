package com;

import java.util.Scanner;

public class Recursive_Ques {
	
	static int i=1;
	static void accending(int n) {
		if(i<=n) {
			System.out.println(i);
			i++;
			accending(n);
		}
	}
	
	
	static void desending(int n) {
		if(n>=1) {
			System.out.println(n);
		
			n--;
			desending(n);
		}
	}
	
	public static void main(String[] args) {
		System.out.println("Q1 write a java program to find 1 to nth natural number using recursing..?");
		Scanner sc = new Scanner (System.in);
		System.out.print("Enter yr number ");
		int n = sc.nextInt();
		accending(n);
		System.out.println("Q1 write a java program to find nth to 1 natural number using recursing..?");
		desending(n);
		
	}

}
