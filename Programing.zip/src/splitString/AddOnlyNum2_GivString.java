package splitString;

public class AddOnlyNum2_GivString {
	
	static int integer(String s) {
		int res =0;
		for(int i=0; i<s.length();i++) {
			int n = (s.charAt(i)-48);
			res=(res*10)+n;
		}
		return res;
	}
	
	
	public static void main(String[] args) {
		
	String s ="Ram shayam and sital has 4000 5000 and 5000 respectively";
	String[] arr=s.split(" ");
	int sum=0,sum1=0;
	
	 for(int i=0; i<arr.length; i++) {
		 char c =arr[i].charAt(0);
		
		 if(c>='0' && c<='9') {
			 
			 sum=sum+Integer.parseInt(arr[i]);//pre
			 
			 sum1=sum1+integer(arr[i]);//user
		
		 }
		 
	 }
	 System.out.println(sum);
	 System.out.println(sum1);
}
}