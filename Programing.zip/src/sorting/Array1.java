package sorting;



public class Array1{
	
	static void arraysort(int[] arr) {
		for(int i=0;  i<arr.length; i++) {
			 for(int j=i+1; j<arr.length; j++) {
				 if(arr[i]>arr[j]) {
						int tem = arr[i];
						arr[i] = arr[j];
						arr[j] = tem;
						}
				 }
			 }
		
		for(int ele : arr) {
			System.out.println(ele);
		}
		
	}
	
	public static void main(String[] args) {
		int[] arr = {10,45,2,1,75,856,45,12};
		arraysort( arr);
		
		System.out.println("===========================");
		
	}

}
