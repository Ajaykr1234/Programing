package String;

import java.util.Scanner;

public class S10_Pallindrom {
	
	static String revString(String s) {
		String s1="";
		for(int i=s.length()-1; i>=0;i--) {
			s1=s1+s.charAt(i);
		}
		return s1;
	}
	
	
	static  String revstring(String s) {
	   String s1 = "";
	   for(int i=0; i<s.length(); i++) {
		   s1=s.charAt(i)+s1;
	   }
		return s1;
	}
	
	// without using any empty sting to check the given Sting is pallindrom or not 
	static boolean rev_String(String s) {
		int i=0,j=s.charAt(0)-i;
		
		while(i>j) {
			if(s.charAt(i)!=s.charAt(j)) {
				return false;
			}
			i++;j--;
		}
		return true;
	}
	
	
public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter yr Sting : ");
		String s = sc.nextLine();
		
		System.out.println(s.equalsIgnoreCase(revString(s))?"pallindrom":"not a pallindrom");
		System.out.println(s.equalsIgnoreCase(revstring(s))?"pallindrom":"not a pallindrom");
		
		System.out.println(rev_String(s)?"pallindrom":"not a pallindrom");
		
		

}
}