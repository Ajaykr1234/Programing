package Recursive;

public class Hello_5times {
	static void display(int n) {
		if(n>=1) {
			System.out.println("hello");
			display(n-1);
		}
		
	}
	
	public static void main(String[] args) {
		System.out.println("Q1. Write a java program to print hello 5times ..?");
		display(5);
		
	}

}
