package com;

public class Bitwise_Op {

	public static void main(String[] args) {
		System.out.println("01.And(&)\n02. Or(|)\n03. XOR(^)\n04 Right shift(>>)\n05 left shift(<<)\n06 negation(~)");
		
		System.out.println("Q1. example of And(&)");
	}
}
