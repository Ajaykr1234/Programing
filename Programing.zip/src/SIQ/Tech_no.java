package SIQ;

import java.util.Scanner;

public class Tech_no {
	static int count(int n) {
		int count =0;
		while(n!=0) {
			n=n/10;
			count++;
		}
		return count;
	}
	
	static int power(int n,int exp) {
		int power=1;
		for(int i=1; i<=exp; i++) {
			power *=n;
			
		}
		return power;
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter yr number : ");
		int n = sc.nextInt();
		int c = count(n);
		if(c%2==0) {
			int m=power(10,c/2);
			System.out.println(m);
			
			int m1= (int) Math.pow(10, c/2); //predefine function
			
			System.out.println("1st Half of no "+n/m);
			System.out.println("2nd Half of no "+n%m);
			System.out.println("Add both half of no "+(n/m+n%m));
		}
		
	}

}
