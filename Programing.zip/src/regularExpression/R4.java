package regularExpression;
import java.util.regex.*;
public class R4 {
	public static void main(String[] args) {
		//WARE to check whether the String contain  (may) or not
		String s = "Ramayana"; 
		Pattern p = Pattern.compile(".*may.*");
		Matcher m = p.matcher(s);
		boolean b = m.matches();
		System.out.println(b);
	}

}
