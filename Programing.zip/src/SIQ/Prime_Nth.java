package SIQ;

import java.util.Scanner;

public class Prime_Nth {
	static boolean nthplacePrime(int n) {
		if(n<=1) {
			return false;
		}
		for(int i=2; i<=n; i++) {
			if(n%i==0) {
				return false;
			}
		}
		return true;
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter yr no ");
		int n = sc.nextInt();
		int count=0;
		for(int i=1; ;i++) {
			if(nthplacePrime(i)) {
				count++;
			}
			if(count==n) {
				System.out.println(i);
				break;
			}
		}
		
	}

}
