package Recursive;

import java.util.Scanner;

public class Natrual_dec {
	static void natural(int n) {
		if(1<=n) {
			System.out.println(n);
			natural(n-1);
		}
	}
	
	
	public static void main(String[] args) {
		System.out.println("Q1 Write a java program to find n to 1 number ..?");
		Scanner sc = new Scanner (System.in);
		System.out.print("Enter yr no : ");
		int n = sc.nextInt();
		natural(n);
	}

}
