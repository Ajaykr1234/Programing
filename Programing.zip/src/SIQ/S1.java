package SIQ;

public class S1 {
	public static void main(String[] args) {
		System.out.println("Write a java program to given problem?");
		// String "Hello how are you" [H][e][l][l][o][][h][o][w][][a][r][e] [] [y] [o] [u]
//		                               0  1  2  3  4  5 6  7  8  9 10 11 12 13  14  15  16
//		n=48 factor=1,2,3,4,6,8,12,16,24,48
//		only print 48 factor number = string index number print char(up to max length of String only)
//		like 1=e,2=e,3=l,4=o,6=h,8=w,12=e,16=u stop because 24 and 48 out of string length 
		
		String s1="Hello how are you";
		int n  = 48;
		for(int i=1; i<s1.length(); i++) {
			if(n%i==0) {
				System.out.print(s1.charAt(i)+" ");
			}
		}
	}

}
