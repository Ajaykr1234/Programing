package Number;

import java.util.Scanner;

public class Add_ResultSingleDigit {
static int add(int n) {
	int rem=0;
    int sum=0;
    while(n!=0) {
    	rem = n%10;
    	sum +=rem;
    	n=n/10;
    }
    return sum;
}
	
	public static void main(String[] args) {
		System.out.println("Q1 Write a java Program to find Reduce to single digit (for example : = 123=6 o/p,451=10=1 o/p,555=15=6 o/p");
		
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter yr no :");
		int n = sc.nextInt();
		while(n>9) {
			n=add(n);
			System.out.println(n);
		}
		
		
	}

}
