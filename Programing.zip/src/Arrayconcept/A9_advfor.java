package Arrayconcept;

public class A9_advfor {
	public static void main(String[] args) {
		int[] arr = {10,20,30,50,};
		int sum=0;
		 for(int res: arr) {
			 System.out.println(res);
			 sum +=res;
		 }
		 System.out.println("sum of all element "+sum);
	}


}
