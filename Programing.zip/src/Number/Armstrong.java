package Number;
import java.util.Scanner;
public class Armstrong {
	
static int countdigit(int n){
int rem=0,count=0;
while(n!=0){
	rem=n%10;
	n=n/10;
	count++;
	
}
return count;
}
static int powerofNo(int n,int exp){
int rem=0,power=1;
for(int i=1;i<=exp; i++){
	power *= n;

}
return power;
}	
	  
public static void main(String[] args) {
	
	System.out.println("Q1. Write a java prgram to find Armstrong number (expl given a number and its total digit also single digit)");
	System.out.println("single digit take as base and total count take as exp like 153 (count=3,digit=base=1)(1^3+5^3+3^3)=153");

	Scanner sc = new Scanner(System.in);
	System.out.print("Enter yr number : ");
	int n = sc.nextInt(),m=n;
	
	int exp=countdigit(n);
	int rem=0,sum=0;
	while(n!=0){
	rem=n%10;
	sum += powerofNo(rem, exp);
	n=n/10;
}
//	System.out.println(exp);
//	System.out.println(sum);
System.out.print(m+" is ");
System.out.println(sum==m?"Armstrong no":"not Armstong\n");	
		
}
}




