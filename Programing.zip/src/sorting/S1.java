package sorting;

public class S1 {
	
	public static void main(String[] args) {
	
	String[] arr = {"Zero","one","two","three","four","five","six","seven","eight","nine"};
	int n=456563;
	String ans="";
	while(n!=0) {
		ans=arr[n%10]+ans;
		n=n/10;
	}
	System.out.println(ans);
}
}