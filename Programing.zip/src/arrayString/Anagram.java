package arrayString;

public class Anagram {
	
	static String sort(char[] arr) {
		
			for(int i=0; i<arr.length; i++) {
				for(int j=i+1; j<arr.length; j++) {
					if(arr[i]>arr[j]) {
					char temp = arr[i];
					arr[i]=arr[j];
					arr[j]=temp;
					}
				}
			}
		
		String s = new String(arr);
		return s;
	}
	
	public static void main(String[] args) {
		String s1="apple";
		String s2="elpap";
		char[] arr1 =s1.toCharArray();
		char[] arr2 =s2.toCharArray();
		if(sort(arr1).equals(sort(arr2))) {
			System.out.println("Anagram");
		}else {
			System.out.println("not a Anagram");
		}
		
	}

}
