package SIQ;

import java.util.Scanner;

public class ArmStrong_number {
	static int count(int n) {
		int count=0;
		while(n!=0) {
		n=n/10;
		count++;
	}
		return count;
	}
	static int power(int base,int exp) {
		int power=1;
		for(int i=1; i<=exp; i++) {
			power *= base;
		}
		return power;
	}
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.print("Enter yr number : ");
	int n = sc.nextInt(),m=n;
	int c = count(n);
	int rem=0,sum=0;
	while(n!=0) {
		rem = n%10;
		sum += power(rem,c);
		n=n/10;
	}
//	System.out.println(sum);
	if(sum==m) {
		System.out.println("ArmStrong ");
	}
	else {
		System.out.println("Not a Armstrong no");
	}
}
}
