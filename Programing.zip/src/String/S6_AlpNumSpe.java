package String;

import java.util.Scanner;

public class S6_AlpNumSpe {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Write a java program to find how many alp num and spe charater present in the user given  String");
		System.out.print("Enter yr String : ");
		String s1 = sc.nextLine();
		int A=0,N=0,S=0;
		for(int i=0; i<s1.length(); i++) {
			char c = s1.charAt(i);
			if((c>='a' && c<='z') || (c>='A' && c<='Z')) {
				A++;
			}
			else if(c>='0'&& c<='9') {
				N++;
			}else {
				S++;
			}
			
		}
		
		System.out.println("Alpha : "+A +"\nnum : "+N+"\nspecial : "+S);
	}

}
