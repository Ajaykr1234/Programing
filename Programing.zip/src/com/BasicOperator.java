package com; 

public class BasicOperator {

	public static void main(String arg[]) {

		// important concept in Arithmetic operator Div
		
		System.out.println("condition1" + "\t" + "condtion2");
		
	

		System.out.print(5 / 2 + "\t \t");
		System.out.println(5 / 2.0);

		System.out.println("------------------------------------------");
		System.out.print(2 / 5 + "\t \t");
		System.out.println(2 / 5.0);

		System.out.println("------------------------------------------");
		System.out.print(0 / 2 + "\t \t");
		System.out.println(0 / 2.0);

		System.out.println("------------------------------------------");
		System.out.println(2 / 0.0);
		// System.out.println(2/0);

		// mod-----------------------------------------------------------------
		System.out.print(5 % 2 + "\t \t");
		System.out.println(5 % 2.0);

		System.out.println("------------------------------------------");
		System.out.print(2 % 5 + "\t \t");
		System.out.println(2 % 5.0);

		System.out.println("------------------------------------------");
		System.out.print(0 % 2 + "\t \t");
		System.out.println(0 % 2.0);

		System.out.println("------------------------------------------");
		System.out.print(5 % 0.0 + "\t \t");
		System.out.println(5 % 0);

	}
}