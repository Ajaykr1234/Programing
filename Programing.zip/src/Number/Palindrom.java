package Number;

import java.util.Scanner;

public class Palindrom {
	static int reverse(int n) {
		int rem=0;
		int rev =0;
		while(n!=0) {
			rem=n%10;
			rev=(rev*10)+rem;
			n=n/10;
		}
		return rev;
	}
	
	public static void main(String[] args) {
		System.out.println("Q1.Write a program to find given no is palindrom or not((no=revno) 10101 reverse 10101 palindrom ; 123 rev 321 not a palindrom..?");
	
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter yr no :");
		int n = sc.nextInt();
		if(n==reverse(n)) {
			System.out.println(n+ " is palindrom "+reverse(n));
	}
		else {
			System.out.println(n+ " is not palindrom "+reverse(n));
		}

}
}