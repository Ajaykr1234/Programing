package String;

public class S2 {
	public static void main(String[] args) {
		String s1="String";
		String s2 ="String";
		String s3 = new String("String");
		String s4 = new String("String");
		System.out.println(s1==s2);//t
		System.out.println(s3==s4);//f
		System.out.println(s2==s4);//f  // here == operator compare with address
		System.out.println("===========================================");
		//go through predefine function
		System.out.println(s1.equals(s2));//t
		System.out.println(s3.equals(s4));//t
		System.out.println(s2.equals(s4));//t but here we compare with value
		
	}

}
