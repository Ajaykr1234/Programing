package regularExpression;
import java.util.regex.*;
public class R6 {
 public static void main(String[] args) {
	//WARE to check whether the String Start with alphabets  or not
	 String s = "Ajay123"; 
	 Pattern p = Pattern.compile("[a-z,A-Z].*");
	 Matcher m = p.matcher(s);
	 boolean b = m.matches();
	 System.out.println(b);
}
}
