package Number;

import java.util.Scanner;

public class Strong_no {
	
	static int facto(int n) {
		int fact =1;    
		for(int i=n; i>=1; i--) {
			fact*=i;
		}
		return fact;
	}
public static void main(String[] args) {
	System.out.println("Q1.Write a program to find Strong number (String number n=145; (1!=1,2!=4,5!=120),");
	Scanner sc = new Scanner(System.in);
	System.out.print("Enter yr no :");
		int n = sc.nextInt();
	
		int m=n;
		int rem=0;
		int sum=0;
		while(n!=0){
			rem =n%10;
			sum+=facto(rem);
			n=n/10;
		}
		if(m==sum) {
			System.out.println("Strong number ");
		}else {
			System.out.println("not a Strong number");
		}
}
}
