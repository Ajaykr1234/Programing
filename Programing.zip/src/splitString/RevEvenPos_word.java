package splitString;

public class RevEvenPos_word {
	
	static String reverse(String s) {
		String rev="";
		for(int i=s.length()-1; i>=0; i--) {
			rev=rev+s.charAt(i);
		}
		return rev;
	}
	public static void main(String[] args) {
		//Q2. Write a java program to reverse even position word in given string
		String s="Ramayana si a yloh book";
		String[] arr = s.split(" ");
		for(int i=0; i<arr.length; i++) {
			if(i%2==1) {
				System.out.print(reverse(arr[i])+" ");
			}else {
				System.out.print(arr[i]+" ");
			}
			
		}
	}

}
