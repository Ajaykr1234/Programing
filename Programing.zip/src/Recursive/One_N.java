package Recursive;

import java.util.Scanner;

public class One_N {
	 static int i=1;
	static void natural(int n) {
//		if(i<=n) {
//			System.out.println(i);
//			i++;
//			 natural(n);
//		}
		
		
		if(1<=n) {
			natural(n-1);
			System.out.println(n);
		}
		
	}
	
	public static void main(String[] args) {
		System.out.println("Q1. Write a java program to find Natural number..?");
		Scanner sc = new Scanner (System.in);
		System.out.print("Enter yr no : ");
		int n = sc.nextInt();
		natural(n);
	}

}
