package globalsoft;
import java.util.Scanner;
public class Q2 {
	
	 static int calculateMaxSand(int n, int[] c, int[] tVal, int[] s) {
	        int[][] dp = new int[n + 1][10001]; 

	        for (int i = 1; i <= n; i++) {
	            for (int j = 0; j <= 10000; j++) {
	                dp[i][j] = dp[i - 1][j];

	                if (j >= tVal[i - 1]) {
	                    dp[i][j] = Math.max(dp[i][j], dp[i - 1][j - tVal[i - 1]] + s[i - 1]);
	                }

	                if (j >= c[i - 1]) {
	                    dp[i][j] = Math.max(dp[i][j], dp[i][j - c[i - 1]] + s[i - 1]);
	                }
	            }
	        }

	        return dp[n][10];
	    }
	
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        System.out.println("enter yr t");
	        int t = scanner.nextInt(); 
	        scanner.nextLine(); 

	        while (t-- > 0) {
	            int n = scanner.nextInt();
	            scanner.nextLine(); 

	            int[] c = new int[n];
	            int[] tVal = new int[n];
	            int[] s = new int[n];

	      
	            for (int i = 0; i < n; i++) {
	                c[i] = scanner.nextInt(); 	
	                tVal[i] = scanner.nextInt(); 	
	                s[i] = scanner.nextInt(); 
	                scanner.nextLine(); 
	            }

	            int maxSand = calculateMaxSand(n, c, tVal, s);
	            System.out.println(maxSand);
	        }

	        scanner.close();
	    }

	   
	}



