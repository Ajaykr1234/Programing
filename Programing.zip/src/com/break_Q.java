package com;
import java.util.Scanner;
public class break_Q {
	public static void main(String[] args) {
System.out.println("Q1.Write a program to find the no b/w 50 to 100 without using any Logical operator(and or) and nesterd if \nif it is found print no is found else no is not found..?");
		
		 Scanner sc = new Scanner(System.in);
		 System.out.print("Enter yr no = ");
		    int n = sc.nextInt();
			int count=0;
		    
		    for(int i=50; i<=100; i++) {
		    	if(i==n) {
		    		count++;
		    		
		    	}
		    }
		    	if(count==1) {
		    		System.out.println("number is found.....!!!!!");
		    	}else {
		    		System.out.println("no is not found....!!!!");
		    	}
	}

	   
	    	
	    

}

