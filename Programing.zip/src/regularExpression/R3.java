package regularExpression;
import java.util.regex.*;
public class R3 {
	public static void main(String[] args) {
		//WARE to check whether the String Staring with with  (R,r) or not
		String s = "Ramayana";
		Pattern p = Pattern.compile("[R,r].*");
		Matcher m = p.matcher(s);
		boolean b =m.matches();
		System.out.println(b);
		
	}

}
