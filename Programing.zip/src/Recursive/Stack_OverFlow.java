package Recursive;

public class Stack_OverFlow {
	
	static void display() {
		System.out.println("hello");
		display();
	}
	
	public static void main(String[] args) {
		display();
		
	}
	
}
