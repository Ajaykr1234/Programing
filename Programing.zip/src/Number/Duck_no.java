package Number;

import java.util.Scanner;

public class Duck_no {
	static String number(int n) {
		int count=0;
		int rem=0;
		while(n!=0) {
			rem=n%10;
			if(rem==0) {
				count++;
			}
			n=n/10;
		}
//				if(count>=1) {
//					System.out.println("Duck number ");
//				}else {
//					System.out.println("not a duck no : ");
//				}
			return count>=1?"Duck no":"not a duck no";
		}
		
public static void main(String[] args) {
	System.out.println("Q1. Write a program to find a duck number (if a number contains single zere or more than zero that given no is duck no else not )");
	Scanner sc = new Scanner(System.in);
	System.out.print("Enter yr no : ");
	int n = sc.nextInt();     
//	  number(n);
	System.out.println(number(n));
}

}
