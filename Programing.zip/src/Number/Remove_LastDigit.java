package Number;
import java.util.Scanner;
public class Remove_LastDigit {
	
	static int remain_no(int n){
		int res=n/10;
		return res;
		
	}
	 
public static void main(String[] args) {
		System.out.println("Q1.Write a program to remove last digit of the given number ..?");
		Scanner sc = new Scanner(System.in);
		System.out.print("enter yr no : ");
		int n = sc.nextInt();
		System.out.println(n+" the last digit are romoved remaining no is : "+remain_no(n));
	}

}
