package String;



public class S14_lenthOfString {
	public static void main(String[] args) {
		
	
	String s ="Hello";
	int i=0;
	try {
		while(true) {
			char c = s.charAt(i);
			i++;
		}
	} catch (Exception e) {
		System.out.println(i);
		
	}

}
}