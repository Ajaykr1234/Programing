package Recursive;

import java.util.Scanner;

public class Factor_number {
	
	static int factor(int n) {
		if(n==0) {
			return 1;
		}
		else {
			return n*factor(n-1);
		}
	}
	
	public static void main(String[] args) {
		System.out.println("Q1 Write a program to find factor of a number ..?");
		
		Scanner sc = new Scanner (System.in);
		System.out.print("Enter yr no : ");
		int n = sc.nextInt();
		System.out.println("the Factorial of "+n+" is "+factor(n));
	}

}
