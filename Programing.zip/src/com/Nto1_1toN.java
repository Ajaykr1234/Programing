package com;

public class Nto1_1toN {
	public static void main(String[] args) {
		System.out.println("Q1. Write a java program to find n to 1 and 1 to n number..?");
		int n=10;
		for(int i=n,j=1; j<=n ; i--,j++) {
			System.out.println(i+ " "+j);
		}
	}

}
