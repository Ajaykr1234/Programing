package String;

public class S4_LowerUpper {
	public static void main(String[] args) {
		// to convert the given sting in lower case just type toLoweCase();
		String s1 = "STriNG";
		String res= s1.toLowerCase();
		System.out.println(res);
		System.out.println("=================================");
		// to convert the given sting in upper  case just type toUpperCase();
		String res1 = s1.toUpperCase();
		System.out.println(res1);
	}

}
