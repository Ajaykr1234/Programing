package com;

public class LOgical_Operator {
	public static void main(String[] args) {

System.out.println("=============================================================");
System.out.println("LOGICAL AND '&' ");
		System.out.println("Q1. find the output of the given below program... ?");
		System.out.println(true && true && true);
		System.out.println(true && true && false);
		
System.out.println("=============================================================");
System.out.println("LOGICAL OR '||' ");
				System.out.println("Q2. find the output of the given below program... ?");
				System.out.println(true || true || true);
				System.out.println(true || true || false);
				
System.out.println("=============================================================");
System.out.println("LOGICAL NOT ! ");
System.out.println("Q3. find the output of the given below program... ?");
						System.out.println(true != true != true);
						System.out.println(true != true != false);
						
System.out.println("=============================================================");
						
System.out.println("Q4. find the output of the given below program... ?");
						System.out.println(true && true != true);
						System.out.println(true || true != false);
						
System.out.println("=============================================================");
System.out.println("Q5. find the output of the given below program... ?");
								System.out.println(true && true || true != true);
								System.out.println(true && true || true !=  false);
		
	}

}
