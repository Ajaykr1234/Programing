package Recursive;

import java.util.Scanner;

public class DescZero_Asce {
	
	static void dis(int n) {
		if(n==0) {
			System.out.print(0);
		}
		else {
			System.out.print(n);
			dis(n-1);
			System.out.print(n);
		}
	}
	
	
	
	
	
	
	public static void main(String[] args) {
System.out.println("Q1 Write a program to find (i/p = 5  o/p=54321012345 ..?");
		
		Scanner sc = new Scanner (System.in);
		System.out.print("Enter yr no : ");
		int n = sc.nextInt();
		dis(n);
	}

}
