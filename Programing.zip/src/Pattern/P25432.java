package Pattern;

import java.util.Scanner;

public class P25432 {
	static void pattern(int n) {
		for(int i=1; i<=n; i++) {
			for(int j=1; j<=n; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
	static void pattern22(int n) {
		for(int i=1; i<=n; i++) {
			for(int j=1; j<=n; j++) {
				if(i>=j) {
					System.out.print("*");
				}else {
					System.out.print("  ");
				}
			}
			System.out.println();
		}
	}
	static void pattern23(int n) {
		for(int i=1; i<=n; i++) {
			for(int j=1; j<=n; j++) {
				if(j>=i) {
					System.out.print("*");
				}else {
					System.out.print(" ");
				}
			}
			System.out.println();
		}
	}
	static void pattern24(int n) {
		for(int i=1; i<=n; i++) {
			for(int j=1; j<=n; j++) {
				if(i+j<=n+1) {
					System.out.print("*");
				}else {
					System.out.print(" ");
				}
			}
			System.out.println();
		}
	}
	static void pattern25(int n) {
		for(int i=1; i<=n; i++) {
			for(int j=1; j<=n; j++) {
				if(i+j>=n+1) {
					System.out.print("*");
				}else {
					System.out.print(" ");
				}
			}
			System.out.println();
		}
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
	    System.out.print("Enter yr number : ");
	    int n = sc.nextInt();
	    pattern(n);
	    System.out.println("======================================");
	    pattern22(n);
	    System.out.println("======================================");
	    pattern23(n);
	    System.out.println("======================================");
	    pattern24(n);
	    System.out.println("======================================");
	    pattern25(n);
	}

}
