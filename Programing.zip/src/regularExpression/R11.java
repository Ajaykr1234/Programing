package regularExpression;
import java.util.regex.*;
public class R11 {
 public static void main(String[] args) {
	//WARE to check whether the for the phone no validation where phone no can be started with 6,7,8,9
	 
	 String s = "6194562584"; 
	 Pattern p = Pattern.compile("[6,7,8,9]{1}[0-9]{9}");
	 Matcher m = p.matcher(s);
	 boolean b = m.matches();
	 System.out.println(b);
}
}
