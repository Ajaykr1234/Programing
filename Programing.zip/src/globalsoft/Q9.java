package globalsoft;

import java.util.Scanner;

public class Q9 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter yr row ");
		int row = sc.nextInt();
		System.out.println("Enter yr col ");
		int col = sc.nextInt();
		int[][] arr = new int[row][col];
		int sum=0;
		for(int i=0; i<arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				System.out.println("game started......");
				System.out.println("payer A Enter yr number..");
				int p1=sc.nextInt();
				arr[i][j]=p1;
				System.out.println("payer A Enter yr number..");
				int p2 = sc.nextInt();
				arr[i][j]=p2;
				sum+=arr[i][j];
				
			}
			if(sum%2==0) {
				System.out.println("Frist win");
			}else {
				System.out.println("Second win");
			}
		}
	}

}
