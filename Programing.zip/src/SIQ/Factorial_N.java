package SIQ;

import java.util.Scanner;

public class Factorial_N {
	static int fact(int n) {
		int fact =1;
		for(int i=1; i<=n; i++) {
			fact *=i;
		}
		return fact;
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter yr number ");
		int n = sc.nextInt();
		System.out.println(n+" fact is "+fact(n));
		
		
	}

}
