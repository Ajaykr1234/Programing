package com;
import java.util.Scanner;
public class Prime_NotPrime {
	public static void main(String[] args) {
		System.out.println("Q1. WRITE A JAVA PROGRAM TO FIND GIVEN NUMBER IS PRIME OR NOT..?");
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter yr number : - ");
		int n = sc.nextInt();
		int count =0;
		for(int i=1; i<=n; i++) {
			if(n%i==0) {
				count++;
			
		}
		}
		if(count==2) {
			System.out.println(n+" is a prime number..!! ");
		}else {
			System.out.println(n+" not a prime number..!!");
		}
	}

	 }

