package SIQ;

import java.util.Scanner;

public class Palindrome {
	static int revNumber(int n) {
		int rem=0,rev=0;
		while(n!=0) {
			rem = n%10;
			rev = (rev*10)+rem;
			n=n/10;
		}
		return rev;
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter yr no : ");
		int n = sc.nextInt();
		if(n==revNumber(n)) {
			System.out.println("Palindrom ");
		}else {
			System.out.println("Not a palindrom ");
		}
		
	}

}
