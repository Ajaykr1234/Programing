package _2D_Array;

import java.util.Iterator;

public class A1 {
	public static void main(String[] args) {
		int[][] arr = {{1,5,8,3},{7,6,2,5},{4,5,6,8}};
		System.out.println(arr.length);
		for (int i = 0; i < arr.length; i++) {
			 System.out.println(arr[i]);
			
	
}
}
}