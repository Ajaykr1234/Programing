package com;
import java.util.Scanner;
public class Continue_Q {
	public static void main(String[] args) {
		
System.out.println("=============================================================");
		System.out.println("Q1. find the output of the given below program... ?");
		for(int i=1; i<=10; i++) {
			if(i==3 || i==7) {
				continue;
			}
			System.out.print( " "+i+" ");
		}
		
System.out.println("=============================================================");
System.out.println("\nQ2.WRITE A JAVA PROGRAM TO FIND PERFECT SQUARE...?");
		Scanner sc = new Scanner (System.in);
		System.out.print("Enter yr number :- ");
		int n = sc .nextInt();
		int count = 0;
		for(int i=1;i<=n;i++) {
			int a = i*i;
			if(n==a) {
				count++;
			}
		}
		if(count==1) {
			System.out.println("perfect square..!!");
		}else {
			System.out.println("not a perfect square..!!");
		}
		
		
	}
    
}
