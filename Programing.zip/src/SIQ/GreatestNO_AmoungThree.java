package SIQ;

import java.util.Scanner;

public class GreatestNO_AmoungThree {
	
	static void greatno(int a ,int b,int c) {
		if(a==b && b==c) {
			System.out.println(a+","+b+" and "+c+" are Equal");
		}
		else if(a>=b && a>=c) {
			System.out.println(a+" is greatest number...");
		}
		else if(b>c) {
			System.out.println(b+" is greatest number...");
		}
		else {
			System.out.println(c+" is greatest number..");
		}
	}
	
	
	
	
	
	
	
	public static void main(String[] args) {
		System.out.println("Write a program to find Greatest number amoung three number..? ");
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter yr 1st no : ");
		int a = sc.nextInt();
		System.out.print("Enter yr 2st no : ");
		int b = sc.nextInt();
		System.out.print("Enter yr 3rd no : ");
		int c = sc.nextInt();
		greatno(a,b,c);
		
	}

}
