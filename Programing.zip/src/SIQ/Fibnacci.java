package SIQ;

import java.util.Scanner;

public class Fibnacci {
static void fib(int n) {
	int n1=0, n2=1,sum=0,i=1;
	while(i!=n) {
		System.out.println(n1);
		sum=n1+n2;
		n1=n2;
		n2=sum;
		i++;
	}
	
}
static void fib1(int n) {
	int n1=0,n2=1,sum=0;
	for(int i=1;i<=n; i++) {
		System.out.println(n1);
		sum=n1+n2;
		n1=n2;
		n2=sum;
	}
}
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.print("Enter yr number: ");
	int n=sc.nextInt();
//	fib1(n);
	fib(n);
	
}
}
