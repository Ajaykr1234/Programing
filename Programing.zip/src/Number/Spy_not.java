package Number;

import java.util.Scanner;

public class Spy_not {
// static int Add(int n) {
//	 int sum=0;
//	 int rem=0;
//	 while(n!=0) {
//		 rem=n%10;
//		 sum +=rem;
//		 n=n/10;
//	 }
//	 return sum;
// }
// static int mul(int n) {
//	 int mul=1;
//	 int rem=0;
//	 while(n!=0) {
//		 rem=n%10;
//		 mul *=rem;
//		 n=n/10;
//	 }
//	 return mul;
// }
	static String addMul(int n) {
		 int sum=0;
		 int mul=1;
		 int rem=0;
		 while(n!=0) {
			 rem=n%10;
			 sum +=rem;
			 mul *=rem;
			 n=n/10;
		 }
		 return sum==mul?"Spy no":"not a spy no";
	 }	
	
 
 
 
public static void main(String[] args) {
	System.out.println("Q1. Write a java program to find given no is spy no or not [syp no a=22; Add(2+2=4); mul(2*2=4) ]..?");
	Scanner sc = new Scanner(System.in);
	System.out.print("Enter yr no :");
		int n = sc.nextInt();
//    System.out.println(Add(n)==mul(n)?"Spy no":" not a spy no");
		System.out.println(addMul(n));
		
}
}
