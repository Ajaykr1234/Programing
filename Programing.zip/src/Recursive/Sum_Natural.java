package Recursive;

import java.util.Scanner;

public class Sum_Natural {
	static int  sum=0;
	static int add(int n) {
		if(1<=n) {
			sum +=n;
			add(n-1);
		}
		return sum;
	}
	
	static int sum(int n) {
		if(n==0) {
			return 0;
		}
		else {
			return n+sum(n-1);
		}
		
	}


	public static void main(String[] args) {
		System.out.println("Q1.write a program to find the sum of natural number..? ");
		Scanner sc = new Scanner (System.in);
		System.out.print("Enter yr no : ");
		int n = sc.nextInt();
		
		System.out.println("the sum of "+n+" natural number is "+add(n));
		System.out.println("the sum of "+n+" natural number is "+sum(n));
	}
}
