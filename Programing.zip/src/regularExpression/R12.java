package regularExpression;
import java.util.regex.*;
public class R12 {
 public static void main(String[] args) {
	//WARE to check whether the for the eamil validation where eamil can be started with 3 to 5 char 
//	 and n no of #, 2 to 5 numeric @gamil.com
	 
	 String s = "ramm#125@gamil.com"; 
	 Pattern p = Pattern.compile("[a-z,A-Z]{3,5}#*[0-9]{2,5}@gmail[.]com");
	 Matcher m = p.matcher(s);
	 boolean b = m.matches();
	 System.out.println(b);
}
}
