package regularExpression;
import java.util.regex.*;
public class R8 {
 public static void main(String[] args) {
	//WARE to check whether the String Start with special char
	 String s = "@#Ajay123"; 
	 Pattern p = Pattern.compile("[^a-z,^A-Z,^0-9].*");
	 Matcher m = p.matcher(s);
	 boolean b = m.matches();
	 System.out.println(b);
}
}
