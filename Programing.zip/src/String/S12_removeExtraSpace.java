package String;

public class S12_removeExtraSpace{
	public static void main(String[] args) {
		
//Q write a program to remove extra space in the given string
	
	String s = "Ramayana   is    holy book";
	
	String ans="";
	for(int i=0; i<s.length(); i++) {
		if(s.charAt(i)==' ' && s.charAt(i+1)==' ') {
			continue;
		
		}else {
			ans=ans+s.charAt(i);
			

	}
 
}
	System.out.println(ans);
}}
