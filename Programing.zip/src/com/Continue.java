package com;

public class Continue {
public static void main(String[] args) {
	
System.out.println("=============================================================");
System.out.println("Q1. find the output of the given below program... ?");
	for(int i=1; i<=10; i++) {
		System.out.println("start.."+i);
		continue;
		
	}
	System.out.println("end");
	

	System.out.println("=============================================================");
	System.out.println("Q2. find the output of the given below program... ?");
	for(int i=1; i<=10; i++) {
		System.out.println("start.."+i);
		
		 
		continue;
//		System.out.println("end"); 
//		(Error:-  unreachable code!!! due to :-continue, hence it never reach to the next line   ");
		
	}

	
	
System.out.println("=============================================================");
System.out.println("Q3. find the output of the given below program... ?");
	for(int i=1; i<=10; i++) {
		System.out.println("start.."+i);
		if(true) {
			continue;
		}
		
		System.out.println("end");
	}
	
}
}
