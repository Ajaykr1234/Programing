package InheritPro;

public abstract class B {
     abstract void disp();
}
