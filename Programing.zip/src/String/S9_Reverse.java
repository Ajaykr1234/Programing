package String;

import java.util.Scanner;

public class S9_Reverse {
	
	static String revString(String s) {
		String s1="";
		for(int i=s.length()-1; i>=0;i--) {
			s1=s1+s.charAt(i);
		}
		return s1;
	}
	
	static  String revstring(String s) {
	   String s1 = "";
	   for(int i=0; i<s.length(); i++) {
		   s1=s.charAt(i)+s1;
	   }
		return s1;
	}
	
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter yr Sting : ");
		String s = sc.nextLine();
		System.out.println("After rev the sting is : "+revString(s));
		System.out.println("After rev the sting is : "+revstring(s));
		
	
	}

}
