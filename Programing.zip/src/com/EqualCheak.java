package com;

public class EqualCheak {

	public static void main (String[] args) {
	
//	write a program to print equal and not equal with out using equal and not equal
		int n1=10;
		int n2=10;
		
		if(n1>n2 || n2>n1) {
			System.out.println(n1+ " is not equal to "+n2);
		}
		else {
			
				System.out.println(n1+ " is  equal to "+n2);
			}
		}
		
	}


		
	

