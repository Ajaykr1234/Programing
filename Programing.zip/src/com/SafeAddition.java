package com;

import java.util.Scanner;

public class SafeAddition {
    public static void main(String[] args) {
        // Create a Scanner for user input
        Scanner scanner = new Scanner(System.in);
        
        int num1, num2;
        
        try {
            // Prompt the user to enter the first number
            System.out.print("Enter the first number: ");
            num1 = scanner.nextInt();

            // Prompt the user to enter the second number
            System.out.print("Enter the second number: ");
            num2 = scanner.nextInt();

            // Add the numbers and store the result in a variable
            int sum = num1 + num2;

            // Print the result to the screen
            System.out.println("The sum of " + num1 + " and " + num2 + " is: " + sum);
        } catch (java.util.InputMismatchException e) {
            System.out.println("Invalid input. Please enter valid integer numbers.");
        } finally {
            // Close the scanner to free up resources
            scanner.close();
        }
    }
}

