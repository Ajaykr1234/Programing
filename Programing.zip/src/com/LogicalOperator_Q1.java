package com;
import java.util.Scanner;
public class LogicalOperator_Q1 {
public static void main(String[] args) {

	System.out.println("QUESTION BASED ON || (or) OPERATOR..? ");
	System.out.println("Q1. Write a java program to cheak given number is divisible by 3 or 5 or 7..?");
	Scanner sc = new Scanner(System.in);
	System.out.print("Enter yr number : - ");
	
	int x = sc.nextInt();
	if(x%7==0 || x%5==0 || x%3==0) {
		System.out.println("the number is divisible ");
	}else {
		System.out.println("number is not divisible by anyone number  ");
	}
}
}
