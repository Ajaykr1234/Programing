package globalsoft;
import java.util.Scanner;
public class Q1 {
  static int MOD = 1000007;

	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        System.out.println("ENter t value");
	        int t = scanner.nextInt();
	        while (t-- > 0) {
	            int n = scanner.nextInt();
	            int k = scanner.nextInt();
	            System.out.println(countConfigurations(n, k));
	        }
	        scanner.close();
	    }

	    static int countConfigurations(int n, int k) {
	        int[][][] dp = new int[n + 1][n + 1][k + 1];

	        dp[0][0][0] = 1;
	        for (int moves = 1; moves <= k; moves++) {
	            for (int i = 0; i <= n; i++) {
	                for (int j = 0; j <= n; j++) {
	                    dp[i][j][moves] = dp[i][j][moves - 1];
	                    if (i >= 2 && j >= 1)
	                        dp[i][j][moves] = (dp[i][j][moves] + dp[i - 2][j - 1][moves - 1]) % MOD;
	                    if (i >= 1 && j >= 2)
	                        dp[i][j][moves] = (dp[i][j][moves] + dp[i - 1][j - 2][moves - 1]) % MOD;
	                    if (i <= n - 2 && j >= 1)
	                        dp[i][j][moves] = (dp[i][j][moves] + dp[i + 2][j - 1][moves - 1]) % MOD;
	                    if (i <= n - 1 && j >= 2)
	                        dp[i][j][moves] = (dp[i][j][moves] + dp[i + 1][j - 2][moves - 1]) % MOD;
	                }
	            }
	        }

	        int totalConfigurations = 0;
	        for (int i = 0; i <= n; i++) {
	            for (int j = 0; j <= n; j++) {
	                totalConfigurations = (totalConfigurations + dp[i][j][k]) % MOD;
	            }
	        }

	        return totalConfigurations;
	    }
	}



