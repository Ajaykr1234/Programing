package com;

public class char_toNumADD {
	public static void main(String[] args) {
		
		
		char a = '1';
		char b = '8';
		
		
//		char a = 1;
//		char b = 8;
		
		
		System.out.println(a+b);
		System.out.println((a-'0')+(b-48));
	}

}
