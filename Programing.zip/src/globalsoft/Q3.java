package globalsoft;
import java.util.Scanner;
public class Q3 {
	 static String calculateWinner(int[][] matrix) {
	        int rows = matrix.length;
	        int cols = matrix[0].length;
	        int xorSum = 0;

	       
	        for (int i = 0; i < rows; i++) {
	            for (int j = 0; j < cols; j++) {
	                xorSum ^= matrix[i][j];
	            }
	        }

	        
	        if (xorSum != 0) {
	            return "FIRST";
	        } else {
	            return "SECOND";
	        }
	    }
	public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        System.out.println("enter t values ");
	        int t = scanner.nextInt();
	        scanner.nextLine(); // 

	        while (t-- > 0) {
	            int n = scanner.nextInt();
	            int m = scanner.nextInt();
	            scanner.nextLine(); 

	            
	            int[][] matrix = new int[n][m];
	            for (int i = 0; i < n; i++) {
	                for (int j = 0; j < m; j++) {
	                    matrix[i][j] = scanner.nextInt();
	                }
	                scanner.nextLine(); 
	            }

	            
	            String result = calculateWinner(matrix);

	          
	            System.out.println(result);
	            
	         
	            if (t > 0) {
	                scanner.nextLine();
	            }
	        }

	        scanner.close();
	    }

	   
	}



