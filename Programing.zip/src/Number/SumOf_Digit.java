package Number;

import java.util.Scanner;

public class SumOf_Digit {
	static int sum(int n) {
		int rem=0;
		int sum=0;
		while(n!=0) {
			rem = n%10;
			sum += rem;
			n=n/10;
		}
		return sum;
	}
	
public static void main(String[] args) {
	System.out.println("Q1.write a java program to find sum of digit to given number  ..? ");
	Scanner sc = new Scanner(System.in);
	System.out.print("Enter yr no : ");
	int n =sc.nextInt();
	System.out.println(n+" the sum of their digit is "+sum(n));
	
}
}
