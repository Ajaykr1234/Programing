package com;

public class While_loop {
	public static void main(String[] args) {

System.out.println("Q1. find the output of the given below program... ?");
		int i=1;
		while(i<=5) {
			
			System.out.print(  i+" " );
			i++;
			
		}
		

System.out.println("\nQ2. find the output of the given below program... ?");
		int j=1;
		while(j<=5) {
			j++;
			System.out.print(  j+" " );
			
			
		}
	}

}
