package com;
import java .util.Scanner;
public class LogicalOperator_Q {
	public static void main(String[] args) {
System.out.println("QUESTION BASED ON & (AND) OPERATOR..? ");
System.out.println("Q1. Write a java program to cheak given number is divisible by 3 and 5..?");
		System.out.print("Enter yr number : - ");
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		if(n%3==0 && n%5==0) {
			System.out.println("the number is divisible by 3 and 5");
		}else {
			System.out.println("number is not divisible by 3 and 5  ");
		}
		
		
		
		
System.out.println("===============================================");
System.out.println("Q2.Write a java program to cheak the given number is between 50 and 100 ..?");
System.out.print("Enter yr number : - ");
		int m = sc.nextInt();
		if(m>=50 && m<=100) {
			System.out.println("the given no is between 50 to 100 ");
		}else {
		System.out.println("the given no not in between 50 to 100 ");
	}
		
		
		
System.out.println("===============================================");
System.out.println("Q3.Write a java program to cheak the given charator  is small Alphabet or not ..?");
System.out.print("Enter yr number : - ");
char c = sc.next().charAt(0);
		if(c>='a' && c<='z') {
			System.out.println("the enter charater is small "+c);
		}else {
		
		System.out.println("the given charactor is caps "+c);
}
		
		
		System.out.println("===============================================");
		System.out.println("Q4.Write a java program to cheak the given charator  is small Alphabets,caps Alphabets ,Numberic or Special char..?");
		System.out.print("Enter yr number : - ");
		char c1= sc.next().charAt(0);
				if(c1>='a' && c1<='z') {
					System.out.println("the enter charater is small "+c1);
				}else if(c1>='A' && c1<='Z'){
				
				System.out.println("the given charactor is caps "+c1);
	} else if(c1>=0 && c1<=9) {
		System.out.println("the given charactor is Number "+c1);
	}else {
		System.out.println("the given charactor is special char "+c1);
	}
				
}
}

