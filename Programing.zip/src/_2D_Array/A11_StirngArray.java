package _2D_Array;

public class A11_StirngArray {
	public static void main(String[] args) {
		char[][] str= {{' '},{'*','#'},{'a','b','c'},{'d','e','f'},{'g','h','i'},{'j','k','l'},{'m','n','o'},{'p','q','r','s'},{'t','u','v'},{'w','x','y','z'}};
		String name="darsan"; 
		int n=0;
		int[] arr=new int[str.length+1];
		
		for(int k=0; k<name.length(); k++) {
			
				char c =name.charAt(k);
				
		        for (int i = 0; i < str.length; i++) {
                    for (int j = 0; j < str[i].length; j++) {
					      if(str[i][j]==c) {
					    	  System.out.println(c+" "+i);
					    	  arr[i]++;
							n+=i;
						}
					  }
				 }
		        
		}
		System.out.println("===================");
		System.out.println(n);
		System.out.println("\n==================");
	
		for(int ele:arr) {
			System.out.print(ele+" ");
		}
		
	}
}
