package com;

public class Do_While {
	public static void main(String[] args) {
		System.out.println("Q1. find the output of the given below program... ?");
		int n=1;
		do {
		 
		
			System.out.println(n);
			n++;
			
		}while(n<=5);
		
		System.out.println("====================================================");
		System.out.println("Q2. find the output of the given below program... ?");
		int m=1;
		do {
		 
		  m++;
			System.out.println(m);
			
			
		}while(m<=5);
	}
	}


