package regularExpression;
import java.util.regex.*;
public class R2 {
	public static void main(String[] args) {
		//WARE to check whether the String Ending with with  (a) or not
		String s = "Ramayana";
		Pattern p=Pattern.compile(".*a");
		Matcher m =p.matcher(s);
		boolean b = m.matches();
		System.out.println(b);
	}
	

}
