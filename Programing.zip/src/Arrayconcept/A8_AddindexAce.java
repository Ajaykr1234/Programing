package Arrayconcept;

public class A8_AddindexAce {
	public static void main(String[] args) {
		int[] arr = {5,10,23,50,78,10,5};
		
		for(int i=0; i<arr.length-1; i++) {
			arr[i]=arr[i]+arr[i+1];
		}
		arr[arr.length-1]=0;
	
	for(int i=0; i<arr.length; i++) {
		System.out.println(arr[i]);
		
	}

}
}