package SIQ;

import java.util.Scanner;

public class PerfectSq_not {
	
	static String isPerfect(int n) {
		int count=0;
		for(int i=1; i<=n; i++) {
			if(i*i==n) {
				count++;
			}
			
		}
		return count==1?"is Perfect Square":"is not a perfect Square";
		
	}
	
	
	
	public static void main(String[] args) {
		System.out.println("Write a program to cheak given number is perfect square or not..? ");
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter yr no : ");
		int n = sc.nextInt();
		System.out.println(n+" "+isPerfect(n));
		
	}

}
