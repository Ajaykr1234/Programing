package _2D_Array;

public class A7_SumOfdia {
	public static void main(String[] args) {
		
//		Q 	Write a program to find sum of diagonal of the given matrix
		
		int[][] arr = {{1,2,3},{4,5,6},{7,8,9}};
		int sum=0;
		for(int i=0; i<arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				System.out.print(arr[i][j]+" ");
				if(i==j) {
					sum+=arr[i][j];
				}
			    
			}
			System.out.println();
		}
		System.out.println("the sum of diagonals is "+sum);
	}

}
