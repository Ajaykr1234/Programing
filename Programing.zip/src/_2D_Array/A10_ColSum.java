package _2D_Array;

public class A10_ColSum {
	
	public static void main(String[] args) {
		
//		Q write a java program to find which row contain max sum
		int[][] arr = {{1,2,3},{4,5,6},{7,8,9}};
		int maxsum=0,k=0;
		for (int i = 0; i < arr.length; i++) {
			int sum=0;
			for (int j = 0; j < arr[i].length; j++) {
				System.out.print(arr[i][j]+"  ");
				}
			System.out.println();
		}
		System.out.println("=======converting row into col==========");
		
		for (int i = 0; i < arr.length; i++) {
			int sum=0;
			for (int j = 0; j < arr[i].length; j++) {
				System.out.print(arr[j][i]+"  ");
				sum+=arr[j][i];
			
			}
		    System.out.println();
			if(maxsum<sum) {
				maxsum=sum;
				k=i+1;
			}

		}
	 System.out.println("col number "+k+" is contain max sum : "+maxsum);
		
	}

}
