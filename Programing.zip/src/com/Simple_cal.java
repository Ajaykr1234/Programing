package com;
import java .util.Scanner;
public class Simple_cal {
	  static int add(int n1, int n2){
	        return n1+n2;
	    }
	     static int sub(int n1, int n2){
	        return n1-n2;
	    }
	     static int mul(int n1, int n2){
	        return n1*n2;
	    }
	     static int divide(int n1, int n2){
	        return n1/n2;
	    }
	     static int mod(int n1, int n2){
	        return n1%n2;
	    }
	     public static void main(String[] args) {
			System.out.println("==Welcome! to Simple calci===");
			Scanner sc = new Scanner(System.in);
			while(true){
			   System.out.println("=====Menu======");
			   System.out.println("1.add\n2.sub\n3.mul\n4.divide\n5.mod\n6.Exit");
			   System.out.print("Choose any option :");
			   int op=sc.nextInt();
			   int n1=0,n2=0;
			   if(op>=1&&op<=5) {
				   System.out.println("Enter your 1st no : ");
				   n1=sc.nextInt();
				   System.out.println("Enter your 2nd no : ");
				   n2=sc.nextInt();
			   }
			  switch(op){
			  case 1: System.out.println("Add : "+add(n1,n2));
			          break;
			          
			          
			  case 2: System.out.println("Sub : "+sub(n1,n2));
			  			break;
			  case 3: System.out.println("Mul : "+mul(n1,n2));
	          			break ;
			  case 4: System.out.println("Divide : "+divide(n1,n2));
	          			break;
			  case 5: System.out.println("mod : "+mod(n1,n2));
	          			break;
			  case 6: System.out.println("===thank you vigite again====");
	                System.exit(0);
	           default : System.out.println(" Please chose correct option...");
				  
			  }
			  
			}
			
			}
		

}
