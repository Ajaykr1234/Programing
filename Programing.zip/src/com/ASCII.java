package com;

public class ASCII {
	public static void main(String[] args) {

//       (char)+(any Numerical value/char) = ASCII
    
//		in this case char will converted into ASCII DEC VALUE)
		
		int a = 'A';
		System.out.println(a);
		
		int b = 'B';
		System.out.println(a+b);
		
		
		System.out.println(a+50);
		
		System.out.println('A'+'B' +"hello");
		
		
		//WE KNOW VERY WELL JAVA PROGRAM EXICUTE RIGHT TO LEFT SO
//		STRING+CHAR = STRING 
//		AGAIN STRING+CHAR= STRING
		
		System.out.println("hello" + 'A'+ 'B');
	     System.out.println("hello" + 'A');
	     System.out.println('A' + "hello");

	}

}
