package _2D_Array;

public class A5_AddAllEle {
	
	static int addof(int[][] arr) {
		
//		Q Write a program to find sum of all elements 
		int  sum=0;
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				sum += arr[i][j];
				
			}
		}
		return sum;
	}
	
	static int addoff(int[][] arr) {
		int  sum=0;
		for (int[] ele : arr) {
			for (int ele1 : ele) {
				sum+=ele1;
			}
			
		}
		return sum;
	}
	public static void main(String[] args) {
		int[][] arr = {{1,5,8,3},{7,6,2,9},{5,5,6,5}};
		System.out.println(addof(arr));
		System.out.println(addoff(arr));
	}

}
